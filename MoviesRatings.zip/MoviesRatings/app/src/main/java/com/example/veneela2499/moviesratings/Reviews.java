package com.example.veneela2499.moviesratings;

public class Reviews {
    String rauthour;
    String rcontent;

    public Reviews(String rrauthor, String rcontent) {
        this.rauthour=rrauthor;
        this.rcontent=rcontent;
    }

    public String getRauthour() {
        return rauthour;
    }

    public void setRauthour(String rauthour) {
        this.rauthour = rauthour;
    }

    public String getRcontent() {
        return rcontent;
    }

    public void setRcontent(String rcontent) {
        this.rcontent = rcontent;
    }
}
