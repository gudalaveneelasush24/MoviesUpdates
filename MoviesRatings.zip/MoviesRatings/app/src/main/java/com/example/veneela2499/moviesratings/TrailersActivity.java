package com.example.veneela2499.moviesratings;

import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class TrailersActivity extends AppCompatActivity {
    @InjectView(R.id.recycler_id_trailers)
    RecyclerView trecyclerView;
    ArrayList<Trailers> trailersArrayList;
    String id;
    InputStream inputStream;
    BufferedReader bufferedReader;
    StringBuilder stringBuilder;
    String nkey,nname,ntype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trailers);
        ButterKnife.inject(this);
        id=getIntent().getStringExtra("ID");

        trailersArrayList=new ArrayList<>();
        TrailersTask trailersTask=new TrailersTask();
        getSupportLoaderManager().initLoader(Integer.parseInt(id),null,trailersTask);

        if(getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private class TrailersTask implements LoaderManager.LoaderCallbacks<String> {
        @NonNull
        @Override
        public Loader<String> onCreateLoader(final int id, @Nullable Bundle args) {
            return new AsyncTaskLoader<String>(TrailersActivity.this) {
                @Override
                protected void onStartLoading() {
                    super.onStartLoading();
                    forceLoad();
                }

                @Nullable
                @Override
                public String loadInBackground() {
                    String UrlLink="https://api.themoviedb.org/3/movie/"+id+"/videos?api_key=3ca91702fd993d9b6701dc56afd8ccd8";
                    try {
                        URL url=new URL(UrlLink);
                        HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
                        httpURLConnection.setRequestMethod("GET");
                        httpURLConnection.connect();
                        inputStream=httpURLConnection.getInputStream();
                        bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
                        stringBuilder=new StringBuilder();
                        String strline="";
                        while ((strline=bufferedReader.readLine())!=null){
                            stringBuilder.append(strline);
                        }
                        return stringBuilder.toString();
                    }  catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                }
            };
        }

        @Override
        public void onLoadFinished(@NonNull Loader<String> loader, String data) {
            trailersArrayList=new ArrayList<>();
            try {
                JSONObject nroot=new JSONObject(data);
                JSONArray narrray=nroot.getJSONArray("results");
                for(int i=0;i<narrray.length();i++){
                    JSONObject jsonObject=narrray.getJSONObject(i);
                    nkey=jsonObject.getString("key");
                    nname=jsonObject.getString("name");
                    ntype=jsonObject.getString("type");
                    Trailers trailers=new Trailers(nkey,nname,ntype);
                    trailersArrayList.add(trailers);
                }
                TrailersAdapt trailersAdapt=new TrailersAdapt(TrailersActivity.this,trailersArrayList);
                trecyclerView.setAdapter(trailersAdapt);
                trecyclerView.setLayoutManager(new LinearLayoutManager(TrailersActivity.this));

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }

        @Override
        public void onLoaderReset(@NonNull Loader<String> loader) {

        }
    }
}
