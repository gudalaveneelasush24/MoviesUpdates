package com.example.veneela2499.moviesratings;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class Adapterclass extends RecyclerView.Adapter<Adapterclass.ViewHolder> {
    ArrayList<MyModel> myModelArrayList;
    Context context;

    public Adapterclass(MainActivity context, ArrayList<MyModel> myModelArrayList) {
        this.myModelArrayList=myModelArrayList;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Picasso.with(context).load(myModelArrayList.get(position).getString())
                .placeholder(R.drawable.loadingn)
                .into(holder.imageView);
        }

    @Override
    public int getItemCount() {
        return myModelArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        public ViewHolder(View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.imageid);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int pos=getAdapterPosition();
                    Intent intent=new Intent(context,DetailsActivity.class);
                    intent.putExtra("ID",myModelArrayList.get(pos).getId());
                    intent.putExtra("PosterPath",myModelArrayList.get(pos).getString());
                    intent.putExtra("VoteAvg",myModelArrayList.get(pos).getVote_average());
                    intent.putExtra("OrgTitle",myModelArrayList.get(pos).getOrgtitle());
                    intent.putExtra("RelDate",myModelArrayList.get(pos).getDate());
                    intent.putExtra("Ovrview",myModelArrayList.get(pos).getOverview());
                    context.startActivity(intent);

                }
            });
        }
    }
}
