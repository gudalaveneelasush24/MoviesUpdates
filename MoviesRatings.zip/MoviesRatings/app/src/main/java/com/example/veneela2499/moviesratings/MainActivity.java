package com.example.veneela2499.moviesratings;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.veneela2499.moviesratings.MovieFav.FavViewModel;
import com.example.veneela2499.moviesratings.MovieFav.MyDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {
    StatefulRecyclervw recyclerView;
    ArrayList<MyModel> myModelArrayList;
    Bundle bun;
    String moviekey;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    FavViewModel favViewModel1;
    List<FavouriteMovies> favouriteMoviesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recylermainid);
        sharedPreferences = getPreferences(MODE_PRIVATE);
        favouriteMoviesList = new ArrayList<>();
        favViewModel1 = ViewModelProviders.of(this).get(FavViewModel.class);
        String valuenew = sharedPreferences.getString("key", "null");
		
		//Saving activity state

        if (valuenew.equalsIgnoreCase("null")) {
            checknetwork();
        } else {
            if (valuenew.equalsIgnoreCase("value")) {
                executePop();
            } else if (valuenew.equalsIgnoreCase("value1")) {
                executeTop();
            } else if (valuenew.equalsIgnoreCase("value2")) {
                displayFvrt();
            } else {
                checknetwork();
            }
        }

        if (getApplicationContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
        } else {
            recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 4));
        }


    }

    public void checknetwork() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if ((networkInfo != null) && (networkInfo.isConnected())) {
            bun = new Bundle();
            bun.putString("mypop", "popular");
            getSupportLoaderManager().initLoader(1, bun, this);
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Check your Network Connection....");
            builder.setTitle("No Network...");
            builder.setCancelable(false);
            builder.setPositiveButton("Close App", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            builder.show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        {
            switch (id) {
                case R.id.popularid:
                    editor = sharedPreferences.edit();
                    editor.putString("key", "value");
                    editor.apply();
                    executePop();
                    break;
                case R.id.topratedid:
                    editor = sharedPreferences.edit();
                    editor.putString("key", "value1");
                    editor.apply();
                    executeTop();
                    break;
                case R.id.favmovid:
                    editor = sharedPreferences.edit();
                    editor.putString("key", "value2");
                    editor.apply();
                    displayFvrt();
                    break;

                default:
                    break;
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void displayFvrt() {
        favViewModel1.getdata().observe(this, new Observer<List<FavouriteMovies>>() {
            @Override
            public void onChanged(@Nullable List<FavouriteMovies> favouriteMovies) {
                favouriteMoviesList = favouriteMovies;
                if (favouriteMoviesList.size() == 0) {
                    Toast.makeText(MainActivity.this, "No Favourites", Toast.LENGTH_SHORT).show();
                } else {
                    FavAdapt favAdapt = new FavAdapt(MainActivity.this, favouriteMoviesList);
                    recyclerView.setAdapter(favAdapt);
                    if (getApplicationContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
                    } else {
                        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 4));
                    }


                }

            }
        });
    }

    private void executeTop() {
        Bundle bundle2 = new Bundle();
        bundle2.putString("mypop", "top_rated");
        getSupportLoaderManager().initLoader(2, bundle2, this);
    }

    private void executePop() {
        Bundle bundle1 = new Bundle();
        bundle1.putString("mypop", "popular");
        getSupportLoaderManager().initLoader(1, bundle1, this);
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {

        moviekey = args.getString("mypop");
        return new AsyncTaskLoader<String>(this) {

            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                forceLoad();
            }

            @Nullable
            @Override
            public String loadInBackground() {
                String UrlLink = "https://api.themoviedb.org/3/movie/" + moviekey + "?api_key=3ca91702fd993d9b6701dc56afd8ccd8";
                try {
                    URL url = new URL(UrlLink);
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    InputStream inputStream = httpURLConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line = "";
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    return stringBuilder.toString();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        myModelArrayList = new ArrayList<>();
        try {
            JSONObject root = new JSONObject(data);
            JSONArray res = root.getJSONArray("results");
            for (int i = 0; i < res.length(); i++) {
                JSONObject jsonObject = res.getJSONObject(i);
                String id = jsonObject.getString("id");
                String Vote_avg = jsonObject.getString("vote_average");
                String string = "https://image.tmdb.org/t/p/w500" + jsonObject.getString("poster_path");
                String orgtitle = jsonObject.getString("original_title");
                String overview = jsonObject.getString("overview");
                String date = jsonObject.getString("release_date");
                MyModel myModel = new MyModel(string, id, Vote_avg, orgtitle, overview, date);
                myModelArrayList.add(myModel);
            }

            Adapterclass adapterclass = new Adapterclass(MainActivity.this, myModelArrayList);
            recyclerView.setAdapter(adapterclass);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
}
