package com.example.veneela2499.moviesratings;

import android.app.ProgressDialog;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class ReviewsActivity extends AppCompatActivity {
    @InjectView(R.id.recycler_id_reviews)
    RecyclerView rrecyclerView;
    @InjectView(R.id.imageviewno)
    ImageView imageView1;
    @InjectView(R.id.noreviewid)
    TextView textView1;
    ArrayList<Reviews> reviewsArrayList;
    String id1;
    InputStream inputStream1;
    BufferedReader bufferedReader1;
    StringBuilder stringBuilder1;
    String rrauthor,rcontent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviews);
        ButterKnife.inject(this);
        imageView1.setVisibility(View.INVISIBLE);
        textView1.setVisibility(View.INVISIBLE);
        id1=getIntent().getStringExtra("ID");
        reviewsArrayList=new ArrayList<>();
        ReviewsTask reviewsTask=new ReviewsTask();
        getSupportLoaderManager().initLoader(Integer.parseInt(id1),null,reviewsTask);

        if(getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private class ReviewsTask implements LoaderManager.LoaderCallbacks<String>{

        @NonNull
        @Override
        public Loader<String> onCreateLoader(final int id, @Nullable Bundle args) {
            return new AsyncTaskLoader<String>(ReviewsActivity.this) {
                @Override
                protected void onStartLoading() {
                    super.onStartLoading();
                    forceLoad();
                }

                @Nullable
                @Override
                public String loadInBackground() {
                    String UrlLink="https://api.themoviedb.org/3/movie/"+id+"/reviews?api_key=3ca91702fd993d9b6701dc56afd8ccd8";
                    try {
                        URL url=new URL(UrlLink);
                            HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
                            httpURLConnection.setRequestMethod("GET");
                            httpURLConnection.connect();
                            inputStream1=httpURLConnection.getInputStream();
                            bufferedReader1=new BufferedReader(new InputStreamReader(inputStream1));
                            stringBuilder1=new StringBuilder();
                            String str1="";
                            while ((str1=bufferedReader1.readLine())!=null){
                                stringBuilder1.append(str1);
                            }
                            return stringBuilder1.toString();
                    } catch (Exception e) {
                            e.printStackTrace();
                        }

                    return null;
                }
            };
        }

        @Override
        public void onLoadFinished(@NonNull Loader<String> loader, String data) {
            reviewsArrayList=new ArrayList<>();
            try {
                JSONObject root1=new JSONObject(data);
                JSONArray rresults=root1.getJSONArray("results");
                for(int i=0;i<rresults.length();i++){
                    JSONObject rjsonObject=rresults.getJSONObject(i);
                    rrauthor=rjsonObject.getString("author");
                    rcontent=rjsonObject.getString("content");
                    Reviews reviews=new Reviews(rrauthor,rcontent);
                    reviewsArrayList.add(reviews);
                }

                if((reviewsArrayList.size())==0)
                {
                    imageView1.setVisibility(View.VISIBLE);
                    textView1.setVisibility(View.VISIBLE);
                }
                ReviewsAdapt reviewsAdapt=new ReviewsAdapt(ReviewsActivity.this,reviewsArrayList);
                rrecyclerView.setAdapter(reviewsAdapt);
                rrecyclerView.setLayoutManager(new LinearLayoutManager(ReviewsActivity.this));
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onLoaderReset(@NonNull Loader<String> loader) {

        }
    }
}
