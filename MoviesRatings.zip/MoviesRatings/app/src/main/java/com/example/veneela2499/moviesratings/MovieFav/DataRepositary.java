package com.example.veneela2499.moviesratings.MovieFav;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;
import android.support.annotation.NonNull;

import com.example.veneela2499.moviesratings.FavouriteMovies;
import com.example.veneela2499.moviesratings.MyDAO;

import java.util.List;

public class DataRepositary {

    private MyDAO myDAO;

    private LiveData<List<FavouriteMovies>> rgetdata;
    DataRepositary(@NonNull Application application){
        MyDatabase myDatabase=MyDatabase.getdbasedata(application);
        myDAO=myDatabase.mydatabaseDao();
        rgetdata=myDAO.getdata();
    }

    public FavouriteMovies checkfav(int id){
        FavouriteMovies favouriteMovies=myDAO.checkfav(id);
        return  favouriteMovies;
    }

    LiveData<List<FavouriteMovies>> getdata(){
        return rgetdata;
    }

    public void insertinto(FavouriteMovies favouriteMovies){
        new insertAsync(myDAO).execute(favouriteMovies);
    }

    private class insertAsync extends AsyncTask<FavouriteMovies,Void,Void> {
        private MyDAO myasyncdao;
         insertAsync(MyDAO myDAO) {
            myasyncdao=myDAO;
        }

        @Override
        protected Void doInBackground(FavouriteMovies... favouriteMovies) {
            myasyncdao.insertinto(favouriteMovies[0]);
            return null;
        }
    }

    public void deleteinto(FavouriteMovies favouriteMovies){
        new deleteAsync(myDAO).execute(favouriteMovies);

    }

    private class deleteAsync extends AsyncTask<FavouriteMovies,Void,Void>{
        private MyDAO myasyncdao2;
         deleteAsync(MyDAO myDAO) {
            myasyncdao2=myDAO;
        }

        @Override
        protected Void doInBackground(FavouriteMovies... favouriteMovies) {
            myasyncdao2.deleteinto(favouriteMovies[0]);
            return null;
        }
    }
}
