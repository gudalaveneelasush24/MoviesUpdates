package com.example.veneela2499.moviesratings;


import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity(tableName = "Favourite_Movies")
public class FavouriteMovies {

    @PrimaryKey(autoGenerate = false)
    @NonNull
    public int id;
    public String voteaverage;
    public String orgtitle;
    public String posterpath;
    public String overview;
    public String date;

     public String getId() {
        return String.valueOf(id);
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVoteaverage() {
        return voteaverage;
    }

    public void setVoteaverage(String voteaverage) {
        this.voteaverage = voteaverage;
    }

    public String getOrgtitle() {
        return orgtitle;
    }

    public void setOrgtitle(String orgtitle) {
        this.orgtitle = orgtitle;
    }

    public String getPosterpath() {
        return posterpath;
    }

    public void setPosterpath(String posterpath) {
        this.posterpath = posterpath;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
