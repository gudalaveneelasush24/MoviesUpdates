package com.example.veneela2499.moviesratings.MovieFav;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.example.veneela2499.moviesratings.FavouriteMovies;

import java.util.List;

public class FavViewModel extends AndroidViewModel{
    private DataRepositary dataRepositary;
    private LiveData<List<FavouriteMovies>> mgetdata;
    public FavViewModel(@NonNull Application application) {
        super(application);
        dataRepositary=new DataRepositary(application);
        mgetdata=dataRepositary.getdata();

    }

    public FavouriteMovies ckeckfav(int id){
        FavouriteMovies favouriteMovies=dataRepositary.checkfav(id);
        return favouriteMovies;
    }

    public LiveData<List<FavouriteMovies>>getdata(){
        return mgetdata;
    }

    public void insert(FavouriteMovies favouriteMovies){
        dataRepositary.insertinto(favouriteMovies);
    }

    public void delete(FavouriteMovies favouriteMovies){
        dataRepositary.deleteinto(favouriteMovies);
    }
}

