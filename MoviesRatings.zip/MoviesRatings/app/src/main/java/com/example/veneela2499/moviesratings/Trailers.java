package com.example.veneela2499.moviesratings;

public class Trailers {
    String tkey;
    String tname;
    String ttype;

    public Trailers(String nkey, String nname, String ntype) {
        this.tkey=nkey;
        this.tname=nname;
        this.ttype=ntype;
    }

    public String getTkey() {
        return tkey;
    }

    public void setTkey(String tkey) {
        this.tkey = tkey;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public String getTtype() {
        return ttype;
    }

    public void setTtype(String ttype) {
        this.ttype = ttype;
    }
}
