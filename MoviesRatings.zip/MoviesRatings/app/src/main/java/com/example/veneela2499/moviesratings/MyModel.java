package com.example.veneela2499.moviesratings;

public class MyModel {
    String string;
    String id;
    String vote_average;
    String orgtitle;
    String overview;
    String date;

    public MyModel(String string, String id, String vote_avg, String orgtitle, String overview, String data) {
        this.string=string;
        this.id=id;
        this.vote_average=vote_avg;
        this.orgtitle=orgtitle;
        this.overview=overview;
        this.date=data;
    }

    public String getString() {
        return string;
    }

    public void setString(String string) {
        this.string = string;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVote_average() {
        return vote_average;
    }

    public void setVote_average(String vote_average) {
        this.vote_average = vote_average;
    }

    public String getOrgtitle() {
        return orgtitle;
    }

    public void setOrgtitle(String orgtitle) {
        this.orgtitle = orgtitle;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
