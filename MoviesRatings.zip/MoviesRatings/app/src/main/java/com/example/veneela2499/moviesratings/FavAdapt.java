package com.example.veneela2499.moviesratings;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class FavAdapt extends RecyclerView.Adapter<FavAdapt.FavHolder> {
    Context context;
    private List<FavouriteMovies> favouriteMoviesList;

    public FavAdapt(MainActivity mainActivity, List<FavouriteMovies> favouriteMoviesList) {
        this.context=mainActivity;
        this.favouriteMoviesList=favouriteMoviesList;
    }

    @NonNull
    @Override
    public FavHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new FavHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavHolder holder, int position) {
        Picasso.with(context).load(String.valueOf(favouriteMoviesList.get(position).getPosterpath())).into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return favouriteMoviesList.size();
    }

    public class FavHolder extends RecyclerView.ViewHolder {
        @InjectView(R.id.imageid)
        ImageView imageView;
        public FavHolder(View itemView) {
            super(itemView);
            ButterKnife.inject(this,itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position=getAdapterPosition();
                    Intent intent=new Intent(context,DetailsActivity.class);
                    intent.putExtra("ID",""+favouriteMoviesList.get(position).getId());
                    intent.putExtra("PosterPath",favouriteMoviesList.get(position).getPosterpath());
                    intent.putExtra("VoteAvg",favouriteMoviesList.get(position).getVoteaverage());
                    intent.putExtra("OrgTitle",favouriteMoviesList.get(position).getOrgtitle());
                    intent.putExtra("RelDate",favouriteMoviesList.get(position).getDate());
                    intent.putExtra("Ovrview",favouriteMoviesList.get(position).getOverview());
                    context.startActivity(intent);
                }
            });
        }
    }
}
