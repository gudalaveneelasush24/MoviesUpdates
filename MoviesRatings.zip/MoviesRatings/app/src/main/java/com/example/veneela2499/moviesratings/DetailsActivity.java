package com.example.veneela2499.moviesratings;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.veneela2499.moviesratings.MovieFav.FavViewModel;
import com.example.veneela2499.moviesratings.MovieFav.MyDatabase;
import com.github.ivbaranov.mfb.MaterialFavoriteButton;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.squareup.picasso.Picasso;

import java.util.List;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class DetailsActivity extends AppCompatActivity {
    @InjectView(R.id.movieimgdetlid)
    ImageView imageView1;
    @InjectView(R.id.titleid)
    TextView titletext;
    @InjectView(R.id.releaseid)
    TextView reldatetext;
    @InjectView(R.id.ratingid)
    TextView ratingtext;
    @InjectView(R.id.overviewid)
    TextView overviewtext;
    @InjectView(R.id.likebuttonid)
    LikeButton likeButton;
    MyDatabase myDatabase;
    FavViewModel favViewModel;

    String id;
    String posterpath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        ButterKnife.inject(this);
        Picasso.with(this).load(getIntent()
                .getStringExtra("PosterPath")).into(imageView1);
        favViewModel=ViewModelProviders.of(this).get(FavViewModel.class);
        posterpath=getIntent().getStringExtra("PosterPath");
        titletext.setText(getIntent().getStringExtra("OrgTitle"));
        reldatetext.setText(getIntent().getStringExtra("RelDate"));
        ratingtext.setText(getIntent().getStringExtra("VoteAvg"));
        overviewtext.setText(getIntent().getStringExtra("Ovrview"));
        id=getIntent().getStringExtra("ID");

        myDatabase=Room.databaseBuilder(this,MyDatabase.class,"movies_db")
                .fallbackToDestructiveMigration().allowMainThreadQueries().build();


        likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                FavouriteMovies favouriteMovies=new FavouriteMovies();
                favouriteMovies.setId(Integer.parseInt(id));
                favouriteMovies.setPosterpath(posterpath);
                favouriteMovies.setDate(getIntent().getStringExtra("RelDate"));
                favouriteMovies.setOrgtitle(getIntent().getStringExtra("OrgTitle"));
                favouriteMovies.setOverview(getIntent().getStringExtra("Ovrview"));
                favouriteMovies.setVoteaverage(getIntent().getStringExtra("VoteAvg"));
                favViewModel.insert(favouriteMovies);
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                FavouriteMovies favouriteMovies=new FavouriteMovies();
                favouriteMovies.setId(Integer.parseInt(id));
                favouriteMovies.setPosterpath(posterpath);
                favouriteMovies.setDate(getIntent().getStringExtra("RelDate"));
                favouriteMovies.setOrgtitle(getIntent().getStringExtra("OrgTitle"));
                favouriteMovies.setOverview(getIntent().getStringExtra("Ovrview"));
                favouriteMovies.setVoteaverage(getIntent().getStringExtra("VoteAvg"));
                favViewModel.delete(favouriteMovies);

            }
        });


        if(getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        savedataFav();

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public void trailersbutton(View view) {
        Intent intent=new Intent(DetailsActivity.this,TrailersActivity.class);
        intent.putExtra("ID",id);
        startActivity(intent);
    }

    public void reviewsbutton(View view) {
        Intent intent=new Intent(DetailsActivity.this,ReviewsActivity.class);
        intent.putExtra("ID",id);
        startActivity(intent);
    }

    public void savedataFav() {

        FavouriteMovies favouriteMovies= favViewModel.ckeckfav(Integer.parseInt(id));
        if (favouriteMovies!=null){
            likeButton.setLiked(true);

        }
        else{
            likeButton.setLiked(false);
        }
    }
}
