package com.example.veneela2499.moviesratings;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class DetailsActivity extends AppCompatActivity {
    @InjectView(R.id.movieimgdetlid)
    ImageView imageView1;
    @InjectView(R.id.titleid)
    TextView titletext;
    @InjectView(R.id.releaseid)
    TextView reldatetext;
    @InjectView(R.id.ratingid)
    TextView ratingtext;
    @InjectView(R.id.overviewid)
    TextView overviewtext;

    String id;
    String posterpath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        ButterKnife.inject(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Picasso.with(this).load(getIntent()
                .getStringExtra("PosterPath")).into(imageView1);
        posterpath=getIntent().getStringExtra("PosterPath");
        titletext.setText(getIntent().getStringExtra("OrgTitle"));
        reldatetext.setText(getIntent().getStringExtra("RelDate"));
        ratingtext.setText(getIntent().getStringExtra("VoteAvg"));
        overviewtext.setText(getIntent().getStringExtra("Ovrview"));
        id=getIntent().getStringExtra("ID");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
