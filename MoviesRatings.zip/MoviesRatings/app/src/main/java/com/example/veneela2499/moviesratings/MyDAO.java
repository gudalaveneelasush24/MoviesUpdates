package com.example.veneela2499.moviesratings;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;
@Dao
public interface MyDAO {

    @Query("SELECT * FROM Favourite_Movies")
    LiveData<List<FavouriteMovies>> getdata();

    @Query("SELECT * FROM Favourite_Movies WHERE id==:id")
    FavouriteMovies checkfav(int id);

    @Insert
    void insertinto(FavouriteMovies favouriteMovies);

    @Delete
    void deleteinto(FavouriteMovies favouriteMovies);
}