package com.example.veneela2499.moviesratings.MovieFav;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.example.veneela2499.moviesratings.FavouriteMovies;
import com.example.veneela2499.moviesratings.MyDAO;

@Database(entities = {FavouriteMovies.class},version = 4,exportSchema = false)
public abstract class MyDatabase extends RoomDatabase {

    public abstract MyDAO mydatabaseDao();

    private static volatile MyDatabase INSTANCE;

    static MyDatabase getdbasedata(final Context cnt){
        if (INSTANCE==null){
            INSTANCE= Room.databaseBuilder(cnt.getApplicationContext(),
                    MyDatabase.class,"my_database")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries().build();
        }
        return INSTANCE;
    }
}
