package com.example.veneela2499.moviesratings;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class ReviewsAdapt extends RecyclerView.Adapter<ReviewsAdapt.ReviewsHolder> {
    Context context;
    ArrayList<Reviews> reviewsArrayList;
    public ReviewsAdapt(ReviewsActivity reviewsActivity, ArrayList<Reviews> reviewsArrayList) {
        this.context=reviewsActivity;
        this.reviewsArrayList=reviewsArrayList;
    }

    @NonNull
    @Override
    public ReviewsHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view=LayoutInflater.from(context).inflate(R.layout.itemreview,parent,false);
            return new ReviewsHolder(view);
        }


    @Override
    public void onBindViewHolder(@NonNull ReviewsHolder holder, int position) {
        holder.authortextView.setText(reviewsArrayList.get(position).getRauthour());
        holder.contenttextview.setText(reviewsArrayList.get(position).getRcontent());
    }

    @Override
    public int getItemCount() {
        return reviewsArrayList.size();
    }

    public class ReviewsHolder extends RecyclerView.ViewHolder {
        @InjectView(R.id.authoridtext)
        TextView authortextView;
        @InjectView(R.id.contentid)
        TextView contenttextview;

        public ReviewsHolder(View itemView) {
            super(itemView);
            ButterKnife.inject(this, itemView);
        }
    }
}
